import React from 'react';
import { Megaphone, ShoppingBag, MessageSquare, ChevronRight, Instagram, Facebook, Twitter, Mail, Phone } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white" dir="rtl">
      {/* Hero Section */}
      <header className="bg-white shadow-sm">
        <nav className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="text-2xl font-bold text-blue-600">FluxMedia</div>
            <div className="hidden md:flex space-x-6 space-x-reverse">
              <a href="#services" className="text-gray-600 hover:text-blue-600">خدماتنا</a>
              <a href="#about" className="text-gray-600 hover:text-blue-600">من نحن</a>
              <a href="#contact" className="text-gray-600 hover:text-blue-600">اتصل بنا</a>
            </div>
          </div>
        </nav>
      </header>

      <main>
        {/* Hero Section */}
        <section className="container mx-auto px-6 py-16">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                نحول رؤيتك إلى استراتيجية رقمية ناجحة
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                نقدم حلولاً استراتيجية مبتكرة تجمع بين التسويق الرقمي وإدارة وسائل التواصل الاجتماعي لتحقيق نمو مستدام لعملك
              </p>
              <button className="bg-blue-600 text-white px-8 py-3 rounded-lg flex items-center hover:bg-blue-700 transition">
                ابدأ الآن
                <ChevronRight className="mr-2" />
              </button>
            </div>
            <div className="md:w-1/2">
              <img 
                src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80"
                alt="Digital Strategy"
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section id="services" className="bg-white py-16">
          <div className="container mx-auto px-6">
            <h2 className="text-3xl font-bold text-center mb-12">خدماتنا</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-blue-50 p-6 rounded-lg">
                <Megaphone className="w-12 h-12 text-blue-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">التسويق الرقمي</h3>
                <p className="text-gray-600">استراتيجيات تسويقية مبتكرة تساعد في نمو عملك</p>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg">
                <ShoppingBag className="w-12 h-12 text-blue-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">إدارة المتاجر الإلكترونية</h3>
                <p className="text-gray-600">نساعدك في إدارة وتطوير متجرك الإلكتروني</p>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg">
                <MessageSquare className="w-12 h-12 text-blue-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">إدارة وسائل التواصل</h3>
                <p className="text-gray-600">إدارة محترفة لحسابات التواصل الاجتماعي</p>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-16">
          <div className="container mx-auto px-6">
            <h2 className="text-3xl font-bold text-center mb-12">تواصل معنا</h2>
            <div className="max-w-4xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <Mail className="w-8 h-8 text-blue-600 mb-4" />
                  <h3 className="text-xl font-semibold mb-2">البريد الإلكتروني</h3>
                  <a href="mailto:Fluxmediaproone@gmail.com" className="text-blue-600 hover:text-blue-800">
                    Fluxmediaproone@gmail.com
                  </a>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <Phone className="w-8 h-8 text-blue-600 mb-4" />
                  <h3 className="text-xl font-semibold mb-2">الهاتف</h3>
                  <p className="text-gray-600">متاح 24/7 للاستشارات</p>
                </div>
              </div>
              <form className="bg-white p-8 rounded-lg shadow-md space-y-6">
                <div>
                  <label className="block text-gray-700 mb-2">الاسم</label>
                  <input type="text" className="w-full px-4 py-2 border rounded-lg" />
                </div>
                <div>
                  <label className="block text-gray-700 mb-2">البريد الإلكتروني</label>
                  <input type="email" className="w-full px-4 py-2 border rounded-lg" />
                </div>
                <div>
                  <label className="block text-gray-700 mb-2">الرسالة</label>
                  <textarea className="w-full px-4 py-2 border rounded-lg h-32"></textarea>
                </div>
                <button className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition">
                  إرسال
                </button>
              </form>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-2xl font-bold mb-4 md:mb-0">FluxMedia</div>
            <div className="flex space-x-6">
              <a href="#" className="hover:text-blue-400"><Instagram /></a>
              <a href="#" className="hover:text-blue-400"><Facebook /></a>
              <a href="#" className="hover:text-blue-400"><Twitter /></a>
            </div>
          </div>
          <div className="text-center mt-8 text-gray-400">
            جميع الحقوق محفوظة © 2024 FluxMedia
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;